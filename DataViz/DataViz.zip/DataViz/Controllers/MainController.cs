﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DataViz.Controllers
{
    public class MainController : Controller
    {
        public ActionResult Main()
        {
            return View ();
        }
    }
}
